package org.cap.dao;

public interface BookDao {

	public void createBookTable();
}
