package org.cap.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository("bookDao")
public class BookDaoImpl implements BookDao{
	
	@Autowired
	private JdbcTemplate jdbcTemp;

	@Override
	public void createBookTable() {
		String sql="create table book(bookid int primary key, bookName varchar(15),"
				+ "author varchar(20), price numeric(8,2))";
		jdbcTemp.execute(sql);
		System.out.println("table created");
	}

}
