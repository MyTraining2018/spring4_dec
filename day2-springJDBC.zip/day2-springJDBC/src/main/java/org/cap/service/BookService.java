package org.cap.service;

public interface BookService {
	public void createBookTable();
}
