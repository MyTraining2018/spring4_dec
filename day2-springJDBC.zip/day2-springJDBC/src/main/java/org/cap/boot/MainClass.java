package org.cap.boot;

import org.cap.config.JavaConfig;
import org.cap.service.BookService;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context=
				new AnnotationConfigApplicationContext(JavaConfig.class);
		
		BookService bookService=(BookService)context.getBean("bookService");
		
		bookService.createBookTable();
		
		
	}

}
